# ANZ Legislation Handoff v9 — covering prompt and distribution/submission roadmap

This ZIP supersedes v8 and uses a **covering prompt** as the primary entry point while preserving the single-repo distribution/submission roadmap.

Start with:

1. `COVERING_PROMPT.md`
2. `HANDOFF.md`
3. `codex/LOCAL_IMPORT_AND_INCORPORATION_PROMPT_V9.md`
4. `codex/MASTER_PROMPT_V9.md`
5. `docs/distribution-submission-map-v9.md`

The `repo-overlay/` directory is intended to be copied into the repository after the ZIP is moved into:

```text
conductor/archive/handoffs/2026-05-19-v9-distribution-submission/
```

The import prompt assumes this downloaded file exists at:

```text
~/Downloads/anz_legislation_handoff_v9_covering_prompt.zip
```

No package publishing, website deployment, registry submission, or marketplace submission should happen during import. Those actions remain gated follow-up work.
